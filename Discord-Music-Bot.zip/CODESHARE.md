
        Owner: https://codeshare.me/@umut,
        Name: Discord Music Bot,
        Type: Bot,
        Category: Discord,
        Language: JavaScript,
        Created At: 06/02/2024 18:52:20,
        Web Link: https://codeshare.me/c/xyuf2q1bon6e9k5z,

        ---------------------------------------------
        Downloaded At: 15/06/2024 13:16:01,
        Downloaded By: https://codeshare.me/@siradant,
        Downloaded By Email: siradannt@gmail.com,
        ----------------------------------------------

        Project Description: An enhanced music bot that is compatible with discord.js v14 and works with slash commands. Discord music bot codes that can be used on any server and are simple to install.,
        
        This project was downloaded from https://codeshare.me by siradant (siradannt@gmail.com)